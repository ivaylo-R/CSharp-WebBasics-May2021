﻿namespace SharedTrip.Models.Users
{
    public class UserLoginFormModel
    {
        public string Username { get; init; }

        public string Password { get; init; }
    }
}
